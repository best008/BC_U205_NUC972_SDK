#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
FILE *fp;
char file_name_str[256];

#define KEY_DOWN  0
#define KEY_UP    1

int key_prev_value[2] = {-1,-1};

int scan_key(int idx)
{
	char *usrAL="ual";
	char *keyN="key";
	char buffer[10];
	int  value;
	memset(file_name_str,0,256);
	sprintf(file_name_str,"/%s/%s%d/value",usrAL,keyN,idx);
	if ((fp = fopen(file_name_str, "rb")) == NULL) {
		printf("Cannot open %s.\n",file_name_str);
		exit(1);
	}
	fread(buffer, sizeof(char), sizeof(buffer) - 1, fp);
	fclose(fp);
	value = atoi(buffer);
	if(value != key_prev_value[idx-1])
	{
        if(value == KEY_DOWN)
        {
            printf("Get /ual/key%d value: %d, key down\n", idx, value);
        }else if(value == KEY_UP)
        {
            printf("Get /ual/key%d value: %d, key up\n", idx, value);
        }else
        {
            printf("Get /ual/key%d value: %d, error\n", idx, value);
        }
        key_prev_value[idx-1] = value;
    }
	return 0;
}

int main(int argc, char **argv)
{
    printf("Start scan key status ...\n");
    while(1)
    {
        scan_key(1);
        usleep(100*1000);
        scan_key(2);
        usleep(100*1000);
    }
	return 0;
}
